const hamburger = document.getElementById("hamburger");

hamburger.addEventListener("click", function () {
    console.log("ok");
})
